"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import {
  Building2,
  Stethoscope,
  Home,
  Users,
  CalendarClock,
  ShieldCheck,
  Smartphone,
  CheckCircle2,
  Lock,
  Zap,
  AlertCircle,
} from "lucide-react";
import "./landing.css";

type Sector = "clinica" | "medico" | "rsa" | "agenzia";

interface FormState {
  email: string;
  companyName: string;
  sector: Sector | "";
}

const TARGET_DATA = [
  {
    id: "clinica" as Sector,
    icon: Building2,
    title: "Cliniche Private",
    emoji: "🏥",
    problem: "Coordinare medici, specialisti e segreteria senza sovrapposizioni",
    description:
      "Sincronizza le agende dei medici in tempo reale. Ottimizza l'occupazione delle sale e offri ai tuoi pazienti un'esperienza di prenotazione fluida, riducendo i tempi di attesa e i no-show.",
    iconClass: "lp-target-card__icon--clinica",
  },
  {
    id: "medico" as Sector,
    icon: Stethoscope,
    title: "Singoli Medici / Studi Associati",
    emoji: "🩺",
    problem: "Troppa burocrazia e cartelle cliniche disorganizzate",
    description:
      "Meno scartoffie, più tempo per i pazienti. Accedi alle cartelle cliniche digitali protette da qualsiasi dispositivo, compila i report clinici velocemente e gestisci i tuoi appuntamenti senza stress.",
    iconClass: "lp-target-card__icon--medico",
  },
  {
    id: "rsa" as Sector,
    icon: Home,
    title: "Case di Riposo / RSA",
    emoji: "🏡",
    problem: "Turni H24 complessi e passaggi di consegne critici",
    description:
      "Garantisci una continuità assistenziale impeccabile. Monitora i turni coperti H24, gestisci i piani terapeutici degli ospiti e organizza i passaggi di consegne tra il personale in modo digitale e sicuro.",
    iconClass: "lp-target-card__icon--rsa",
  },
  {
    id: "agenzia" as Sector,
    icon: Users,
    title: "Agenzie di Staffing",
    emoji: "🤝",
    problem: "Allocare il personale giusto nelle strutture giuste all'ultimo minuto",
    description:
      "Pianifica e assegna il personale in pochi clic. Verifica all'istante le disponibilità di infermieri e OSS, gestisci i contratti di somministrazione e rispondi alle richieste di emergenza in tempo reale.",
    iconClass: "lp-target-card__icon--agenzia",
  },
];

const FEATURES_DATA = [
  {
    icon: CalendarClock,
    title: "Calendario Intelligente",
    description:
      "Algoritmi che suggeriscono la copertura ottimale dei turni, evitando i conflitti di orario e riducendo gli straordinari dello staff.",
  },
  {
    icon: ShieldCheck,
    title: "Anagrafica GDPR-Compliant",
    description:
      "Dati sensibili criptati e accessi tracciati per essere sempre in regola con le severissime normative sulla privacy sanitaria.",
  },
  {
    icon: Smartphone,
    title: "Interfaccia Mobile per Operatori",
    description:
      "Infermieri e OSS possono vedere i loro turni direttamente dallo smartphone, segnalare la presenza o richiedere ferie in un tocco.",
  },
];

export default function LandingPage() {
  const joinWaitlist = useMutation(api.waitlist.joinWaitlist);
  const [form, setForm] = useState<FormState>({
    email: "",
    companyName: "",
    sector: "",
  });
  const [status, setStatus] = useState<{
    type: "success" | "error" | null;
    message: string;
  }>({ type: null, message: "" });
  const [loading, setLoading] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Intersection Observer per le animazioni scroll
  const observerRef = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    observerRef.current = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("lp-animate--visible");
          }
        });
      },
      { threshold: 0.1, rootMargin: "0px 0px -50px 0px" }
    );

    const elements = document.querySelectorAll(".lp-animate");
    elements.forEach((el) => observerRef.current?.observe(el));

    return () => observerRef.current?.disconnect();
  }, []);

  const handleSubmit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();
      if (!form.email || !form.sector) {
        setStatus({
          type: "error",
          message: "Inserisci email e seleziona il tuo settore.",
        });
        return;
      }

      setLoading(true);
      setStatus({ type: null, message: "" });

      try {
        const result = await joinWaitlist({
          email: form.email,
          companyName: form.companyName || undefined,
          sector: form.sector as Sector,
        });

        if (result.success) {
          setStatus({ type: "success", message: result.message });
          setForm({ email: "", companyName: "", sector: "" });
        } else {
          setStatus({ type: "error", message: result.message });
        }
      } catch {
        setStatus({
          type: "error",
          message: "Errore di connessione. Riprova tra qualche istante.",
        });
      } finally {
        setLoading(false);
      }
    },
    [form, joinWaitlist]
  );

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setMobileMenuOpen(false);
  };

  return (
    <div className="landing-root">
      {/* Ambient orbs */}
      <div className="lp-orb lp-orb--1" />
      <div className="lp-orb lp-orb--2" />
      <div className="lp-orb lp-orb--3" />

      {/* Navbar */}
      <div className="lp-container">
        <nav className="lp-nav" role="navigation" aria-label="Navigazione principale">
          <a href="/landing-page" className="lp-nav__logo" aria-label="CareLogixAI Home">
            <span className="lp-nav__logo-icon">⚕️</span>
            <span>CareLogixAI</span>
          </a>

          <ul
            className={`lp-nav__links ${mobileMenuOpen ? "lp-nav__links--open" : ""}`}
          >
            <li>
              <button
                className="lp-nav__link"
                onClick={() => scrollToSection("target")}
                style={{ background: "none", border: "none", cursor: "pointer" }}
              >
                Soluzioni
              </button>
            </li>
            <li>
              <button
                className="lp-nav__link"
                onClick={() => scrollToSection("features")}
                style={{ background: "none", border: "none", cursor: "pointer" }}
              >
                Funzionalità
              </button>
            </li>
            <li>
              <button
                className="lp-nav__cta"
                onClick={() => scrollToSection("hero-form")}
              >
                Accesso Anticipato
              </button>
            </li>
          </ul>

          <button
            className="lp-nav__hamburger"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Menu"
          >
            <span />
            <span />
            <span />
          </button>
        </nav>
      </div>

      {/* ===== HERO ===== */}
      <section className="lp-hero">
        <div className="lp-container">
          <div className="lp-hero__badge">
            <span className="lp-hero__badge-dot" />
            Accesso Anticipato Aperto
          </div>

          <h1 className="lp-hero__title">
            La gestione della tua struttura sanitaria,{" "}
            <span className="lp-hero__title-accent">
              semplificata dall&apos;Intelligenza Artificiale.
            </span>
          </h1>

          <p className="lp-hero__subtitle">
            CareLogixAI ottimizza la pianificazione dei turni, automatizza la
            gestione dei pazienti e riduce i costi operativi. Tutto in
            un&apos;unica piattaforma sicura e conforme alle normative sanitarie.
          </p>

          {/* CTA Form */}
          <div className="lp-hero-form-wrapper">
            <span className="lp-hero-form-wrapper__label">
              🚀 Entra nella Whitelist
            </span>
            <form
              id="hero-form"
              className="lp-hero-form"
              onSubmit={handleSubmit}
              noValidate
            >
            <div className="lp-hero-form__row">
              <input
                id="waitlist-email"
                type="email"
                className="lp-hero-form__input"
                placeholder="La tua email professionale"
                value={form.email}
                onChange={(e) =>
                  setForm((prev) => ({ ...prev, email: e.target.value }))
                }
                required
              />
              <select
                id="waitlist-sector"
                className="lp-hero-form__select"
                value={form.sector}
                onChange={(e) =>
                  setForm((prev) => ({
                    ...prev,
                    sector: e.target.value as Sector | "",
                  }))
                }
                required
              >
                <option value="" disabled>
                  Il tuo settore
                </option>
                <option value="clinica">🏥 Clinica Privata</option>
                <option value="medico">🩺 Medico / Studio</option>
                <option value="rsa">🏡 RSA / Casa di Riposo</option>
                <option value="agenzia">🤝 Agenzia Staffing</option>
              </select>
            </div>

            <div className="lp-hero-form__row">
              <input
                id="waitlist-company"
                type="text"
                className="lp-hero-form__input"
                placeholder="Nome struttura / azienda (opzionale)"
                value={form.companyName}
                onChange={(e) =>
                  setForm((prev) => ({
                    ...prev,
                    companyName: e.target.value,
                  }))
                }
              />
              <button
                id="waitlist-submit"
                type="submit"
                className={`lp-hero-form__btn ${loading ? "lp-hero-form__btn--loading" : ""}`}
                disabled={loading}
              >
                Richiedi l&apos;Accesso Anticipato →
              </button>
            </div>

            {status.type && (
              <div
                className={`lp-hero-form__msg lp-hero-form__msg--${status.type}`}
                role="alert"
              >
                {status.type === "success" ? (
                  <CheckCircle2
                    size={16}
                    style={{
                      display: "inline",
                      verticalAlign: "middle",
                      marginRight: 6,
                    }}
                  />
                ) : (
                  <AlertCircle
                    size={16}
                    style={{
                      display: "inline",
                      verticalAlign: "middle",
                      marginRight: 6,
                    }}
                  />
                )}
                {status.message}
              </div>
            )}
          </form>
          </div>

          {/* Trust signals */}
          <div className="lp-hero__trust">
            <div className="lp-hero__trust-item">
              <Lock size={16} className="lp-hero__trust-icon" />
              GDPR Compliant
            </div>
            <div className="lp-hero__trust-item">
              <ShieldCheck size={16} className="lp-hero__trust-icon" />
              Crittografia End-to-End
            </div>
            <div className="lp-hero__trust-item">
              <Zap size={16} className="lp-hero__trust-icon" />
              Setup in 5 minuti
            </div>
          </div>
        </div>
      </section>

      {/* ===== TARGET SECTION ===== */}
      <section className="lp-section" id="target">
        <div className="lp-container">
          <div className="lp-section__header lp-animate">
            <span className="lp-section__tag">Soluzioni</span>
            <h2 className="lp-section__title">
              Fatto su misura per il tuo settore
            </h2>
            <p className="lp-section__desc">
              Ogni realtà sanitaria ha esigenze specifiche. CareLogixAI si
              adatta al tuo contesto operativo con strumenti dedicati.
            </p>
          </div>

          <div className="lp-targets">
            {TARGET_DATA.map((target, i) => (
              <div
                key={target.id}
                className="lp-target-card lp-animate"
                style={{ transitionDelay: `${i * 100}ms` }}
              >
                <div className={`lp-target-card__icon ${target.iconClass}`}>
                  <target.icon size={28} />
                </div>
                <h3 className="lp-target-card__title">
                  {target.emoji} {target.title}
                </h3>
                <p className="lp-target-card__problem">
                  <AlertCircle size={14} />
                  {target.problem}
                </p>
                <p className="lp-target-card__desc">{target.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== FEATURES SECTION ===== */}
      <section className="lp-section" id="features">
        <div className="lp-container">
          <div className="lp-section__header lp-animate">
            <span className="lp-section__tag">Funzionalità</span>
            <h2 className="lp-section__title">
              Tecnologia che lavora per te
            </h2>
            <p className="lp-section__desc">
              Non solo funzionalità: risultati concreti che trasformano il tuo
              modo di lavorare.
            </p>
          </div>

          <div className="lp-features">
            {FEATURES_DATA.map((feature, i) => (
              <div
                key={feature.title}
                className="lp-feature lp-animate"
                style={{ transitionDelay: `${i * 100}ms` }}
              >
                <div className="lp-feature__icon">
                  <feature.icon size={24} />
                </div>
                <div>
                  <h3 className="lp-feature__title">{feature.title}</h3>
                  <p className="lp-feature__desc">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== BOTTOM CTA ===== */}
      <section className="lp-cta-section" id="cta">
        <div className="lp-container">
          <div className="lp-cta-box lp-animate">
            <h2 className="lp-cta-box__title">
              Pronto a trasformare la tua gestione sanitaria?
            </h2>
            <p className="lp-cta-box__desc">
              Unisciti alle strutture che hanno già richiesto l&apos;accesso
              anticipato. Posti limitati per la fase beta.
            </p>
            <button
              className="lp-hero-form__btn"
              onClick={() => scrollToSection("hero-form")}
            >
              Richiedi l&apos;Accesso Ora →
            </button>
          </div>
        </div>
      </section>

      {/* ===== FOOTER ===== */}
      <footer className="lp-footer">
        <div className="lp-container">
          <p>
            © {new Date().getFullYear()} CareLogixAI — Tutti i diritti
            riservati.
            <br />
            <a href="/privacy">Privacy Policy</a> ·{" "}
            <a href="/terms">Termini di Servizio</a>
          </p>
        </div>
      </footer>
    </div>
  );
}
